package com.tamco.driver;

public class Pickupmodel {
    private String name;
    private String id;
    private String img;
    private String iddd;
    private String date;
    private String status;
    private String drs_unique_id;
    private String csa;
    private String attempt;
    private String refno;

    public String getCsa() {
        return csa;
    }

    public void setCsa(String csa) {
        this.csa = csa;
    }

    public String getAttempt() {
        return attempt;
    }

    public void setAttempt(String attempt) {
        this.attempt = attempt;
    }

    public String getRefno() {
        return refno;
    }

    public void setRefno(String refno) {
        this.refno = refno;
    }

    public String getDrs_unique_id() {
        return drs_unique_id;
    }

    public void setDrs_unique_id(String drs_unique_id) {
        this.drs_unique_id = drs_unique_id;
    }

    public Pickupmodel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getIddd() {
        return iddd;
    }

    public void setIddd(String iddd) {
        this.iddd = iddd;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
