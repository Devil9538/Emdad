package com.tamco.driver;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Scandrsadapter extends RecyclerView.Adapter<Scandrsadapter.MyViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<Pickupmodel> rogerModelArrayList;
    Context mcontext;
    public Scandrsadapter(Context ctx, ArrayList<Pickupmodel> rogerModelArrayList){

        inflater = LayoutInflater.from(ctx);
        mcontext=ctx;
        this.rogerModelArrayList = rogerModelArrayList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.scandrsadapter, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        //Picasso.load(rogerModelArrayList.get(position).getImg()).into(holder.iv);
        holder.awbnumberno.setText(""+ Html.fromHtml(rogerModelArrayList.get(position).getName()));
    }

    @Override
    public int getItemCount() {
        return rogerModelArrayList.size();
    }
    public String parseDateToddMMyyyy(String time) {
        String inputPattern = "yyyy-MM-dd HH:mm:ss";
        String outputPattern = "dd-MM-yyyy h:mm a";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);

        Date date = null;
        String str = null;

        try {
            date = inputFormat.parse(time);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }
    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView awbnumberno, name, city,id;
        ImageView iv;

        public MyViewHolder(View itemView) {
            super(itemView);

            awbnumberno = (TextView) itemView.findViewById(R.id.awbnumberno);

        }

    }

}
