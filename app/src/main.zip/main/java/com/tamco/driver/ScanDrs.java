package com.tamco.driver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ScanDrs extends AppCompatActivity {
    LinearLayout l1,l2;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    EditText edittext;
    private static ProgressDialog mProgressDialog;
    String id="";
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    private RecyclerView recyclerView;
    ArrayList<Pickupmodel> pickupmodelslist;
    private Scandrsadapter adapter;
    String uid="";
   // private static ProgressDialog mProgressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_drs);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("");
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        editor = pref.edit();
        id=pref.getString("id",null);
        Intent ii=getIntent();
        uid=ii.getStringExtra("scanvalue");
        edittext=(EditText)findViewById(R.id.edittext);
        l1=(LinearLayout)findViewById(R.id.l1);
        l2=(LinearLayout)findViewById(R.id.l2);
        recyclerView = findViewById(R.id.recycler);
        pickupmodelslist= new ArrayList<>();

        l1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                if (checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MY_CAMERA_REQUEST_CODE);
                }
                else
                {
                    Intent i = new Intent(ScanDrs.this, SimpleScannerActivity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
            }
        });
        edittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                 if(s.length()>12)
                 {
                     adapter = new Scandrsadapter(ScanDrs.this,pickupmodelslist);
                     scandrs();
                 }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        if(uid!=null)
        {
            System.out.println("uid is"+uid);
            adapter = new Scandrsadapter(ScanDrs.this,pickupmodelslist);
            scandrs1();
        }
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              if(edittext.getText().toString().equals(""))
              {
                  edittext.setError("Enter AWB Number");
              }
              else
              {
                  shipmentDetailforDrs();
              }
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {

        onBackPressed();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        return true;
    }

    @Override

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_CAMERA_REQUEST_CODE) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

               // Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();

            } else {

               // Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();

            }

        }}//end onRequestPermi


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                Log.d("MainActivity", "Cancelled scan");
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
                uid=result.getContents();
                Log.d("MainActivity", "Scanned");
               // Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();


            }
        } else {
            // This is important, otherwise the result will not be passed to the fragment
            super.onActivityResult(requestCode, resultCode, data);
        }
    }



    public void scandrs()
    {
        mProgressDialog = ProgressDialog.show(this, "Scan Drs", "Loading..");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fast-option.com/tamco/driver_new.php?method_name=scanDrs&slip_no="+edittext.getText().toString()+"&messanger_id=1&user_id=1", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mProgressDialog.dismiss();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
                pickupmodelslist.clear();
                try {

                    JSONObject jsonObject = new JSONObject(response);
                    String responsestatus = jsonObject.getString("status");
                    Log.d("ADebugTag", "Value: " + responsestatus);

                    if (responsestatus.equals("1")) {

                        JSONArray jsonarray =jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonarray.length(); i++) {
                            Pickupmodel ii = new Pickupmodel();
                            JSONObject jsonobject = jsonarray.getJSONObject(i);
                            String name = jsonobject.getString("shipment_id");
                            ii.setName(name);
                            pickupmodelslist.add(ii);
                        }
                        recyclerView.setAdapter(adapter);
                        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                        adapter.notifyDataSetChanged();
                        System.out.println("response is : " + response);

                    }
                    else if(responsestatus.equals("0"))
                    {
                        Toast.makeText(ScanDrs.this,"AWB Not Found!",Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(ScanDrs.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", ""+id);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }




    public void scandrs1()
    {
        mProgressDialog = ProgressDialog.show(this, "Scan Drs", "Loading..");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fast-option.com/tamco/driver_new.php?method_name=barcodescanDrs&drs_unique_id="+uid+"&messanger_id=1", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mProgressDialog.dismiss();
                pickupmodelslist.clear();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String responsestatus = jsonObject.getString("status");
                    Log.d("ADebugTag", "Value: " + responsestatus);

                    if (responsestatus.equals("1")) {

                        JSONArray jsonarray =jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonarray.length(); i++) {
                            Pickupmodel ii = new Pickupmodel();
                            JSONObject jsonobject = jsonarray.getJSONObject(i);
                            String name = jsonobject.getString("slip_no");
                            ii.setName(name);
                            pickupmodelslist.add(ii);
                        }
                        recyclerView.setAdapter(adapter);
                        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                        adapter.notifyDataSetChanged();
                        System.out.println("response is : " + response);

                    }
                    else if(responsestatus.equals("0"))
                    {
                        Toast.makeText(ScanDrs.this,"AWB Not Found!",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(ScanDrs.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", ""+id);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }


    public void shipmentDetailforDrs()
    {
        mProgressDialog = ProgressDialog.show(this, "Pick Up ", "Loading..");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fast-option.com/tamco/driver_new.php?method_name=shipmentDetailforDrs&drs_unique_id="+uid+"&messanger_id=1&slip_no="+edittext.getText().toString()+"", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mProgressDialog.dismiss();
                pickupmodelslist.clear();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String responsestatus = jsonObject.getString("status");
                    Log.d("ADebugTag", "Value: " + responsestatus);

                    if (responsestatus.equals("1")) {

                        JSONArray jsonarray =jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonarray.length(); i++) {
                            Pickupmodel ii = new Pickupmodel();
                            JSONObject jsonobject = jsonarray.getJSONObject(i);
                            String name = jsonobject.getString("slip_no");
                            ii.setName("SHIPMENT No.:"+name+"<br> Reciever Phone:"+jsonobject.getString("reciever_phone")+"<br> Reciever Address:"+jsonobject.getString("reciever_address")+"<br> Reciever Name:"+jsonobject.getString("reciever_name"));
                            pickupmodelslist.add(ii);
                        }
                        recyclerView.setAdapter(adapter);
                        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                        adapter.notifyDataSetChanged();
                        System.out.println("response is : " + response);

                    }
                    else if(responsestatus.equals("0"))
                    {
                        Toast.makeText(ScanDrs.this,"Shipment not exists!",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(ScanDrs.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", ""+id);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }

}
