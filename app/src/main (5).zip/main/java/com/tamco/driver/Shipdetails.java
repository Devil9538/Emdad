package com.tamco.driver;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Shipdetails extends AppCompatActivity {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String id="",bid="",status="";
    Spinner s1;
    Button button,button1;
    private static ProgressDialog mProgressDialog;
    TextView length,width,height,weight,awbno,refno,cal,date2,name,location,mail,phone,cname,clocation,cmail,cphone,bookingdate,parcel,shipment,cod,pod;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipdetails);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        editor = pref.edit();
        id=pref.getString("id",null);
        Intent ii=getIntent();
        bid=ii.getStringExtra("bid");
System.out.println("bid is"+bid);
        awbno=(TextView)findViewById(R.id.awbno);
        bookingdate=(TextView)findViewById(R.id.bookingdate);
        parcel=(TextView)findViewById(R.id.parcel);
        shipment=(TextView)findViewById(R.id.shipment);
        cod=(TextView)findViewById(R.id.cod);
        pod=(TextView)findViewById(R.id.pod);
        refno=(TextView)findViewById(R.id.refno);
        date2=(TextView)findViewById(R.id.date2);
        cal=(TextView)findViewById(R.id.cal);
        location=(TextView)findViewById(R.id.location);
        mail=(TextView)findViewById(R.id.mail);
        phone=(TextView)findViewById(R.id.phone);
        name=(TextView)findViewById(R.id.name);
        cname=(TextView)findViewById(R.id.cname);
        clocation=(TextView)findViewById(R.id.clocation);
        cmail=(TextView)findViewById(R.id.cmail);
        cphone=(TextView)findViewById(R.id.cphone);
        length=(TextView)findViewById(R.id.length);
        width=(TextView)findViewById(R.id.width);
        height=(TextView)findViewById(R.id.height);
        weight=(TextView)findViewById(R.id.weight);
        login();
        System.out.println("http://www.fast-option.com/tamco/driver_new.php?method_name=booking_detail&user_id=1&booking_id="+bid+"");
        s1=(Spinner)findViewById(R.id.s1);
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                status=s1.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        button=(Button)findViewById(R.id.button);
        button1=(Button)findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(status==null)
                {
                    ((TextView)s1.getSelectedView()).setError("Select Status");
                }
                else if(status.equals("Select Status")){
                    ((TextView)s1.getSelectedView()).setError("Select Status");
                }
                else
                {
                    Intent i = new Intent(Shipdetails.this, Canvas.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {

        onBackPressed();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        return true;
    }




    public void login()
    {
        mProgressDialog = ProgressDialog.show(this, "DRS List", "Loading..");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fast-option.com/tamco/driver_new.php?method_name=booking_detail&user_id=1&booking_id="+bid+"", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mProgressDialog.dismiss();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();

                System.out.println("response is - "+response);
                try {
                    JSONObject jsonobject = new JSONObject(response);
                   // JSONObject jsonarray =new JSONObject();
                 //   JSONObject jsonobject = response;
                    JSONArray jk=jsonobject.getJSONArray("diamention");
                    JSONObject jk1=jk.getJSONObject(0);
                    //String name = jsonobject.getString("delivered");
                    awbno.setText("AWB No.:"+jsonobject.getString("slip_no"));
                    refno.setText("Ref No.:"+jsonobject.getString("booking_id"));
                    cal.setText(""+jsonobject.getString("req_delevery_time"));
                    date2.setText(""+jsonobject.getString("time_slot"));
                    name.setText(""+jsonobject.getString("reciever_name"));
                    location.setText(""+jsonobject.getString("reciever_address"));
                    mail.setText(""+jsonobject.getString("reciever_email"));
                    phone.setText(""+jsonobject.getString("reciever_phone"));
                    cname.setText(""+jsonobject.getString("sender_name"));
                    clocation.setText(""+jsonobject.getString("sender_address"));
                    cmail.setText(""+jsonobject.getString("sender_email"));
                    cphone.setText(""+jsonobject.getString("sender_phone"));
                    bookingdate.setText(""+jsonobject.getString("entrydate"));
                    length.setText("LENGTH: "+jk1.getString("length"));
                    width.setText("WIDTH: "+jk1.getString("width"));
                    height.setText("HEIGHT: "+jk1.getString("height"));
                    weight.setText("WEIGHT: "+jk1.getString("wieght"));
                    parcel.setText("ParcelDescription:");
                    shipment.setText("Shipment Type:"+jsonobject.getString("mode"));
                    cod.setText("COD Amount: 0.00(SAR)");
                    pod.setText(""+jsonobject.getString("code"));

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(Shipdetails.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", ""+id);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }
}
