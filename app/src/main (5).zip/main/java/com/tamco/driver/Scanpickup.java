package com.tamco.driver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Scanpickup extends AppCompatActivity {
    LinearLayout l1,l2;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    EditText edittext;
    private static ProgressDialog mProgressDialog;
    String id="";
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    private RecyclerView recyclerView;
    ArrayList<Pickupmodel> pickupmodelslist;
    private Scandrsadapter adapter;
    String uid="",slip="";
    TextView slip_no;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanpickup);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("");
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        editor = pref.edit();
        id=pref.getString("id",null);
        Intent ii=getIntent();
        uid=ii.getStringExtra("scanvalue");
      //  edittext=(EditText)findViewById(R.id.edittext);
        l1=(LinearLayout)findViewById(R.id.l1);
        l2=(LinearLayout)findViewById(R.id.l2);
        recyclerView = findViewById(R.id.recycler);
        pickupmodelslist= new ArrayList<>();
        slip_no=(TextView)findViewById(R.id.slip_no);
        l1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                if (checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MY_CAMERA_REQUEST_CODE);
                }
                else
                {
                    Intent i = new Intent(Scanpickup.this, SimpleScannerActivity1.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
            }
        });
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(slip_no.getText().toString().equals("")) {
                    Toast.makeText(Scanpickup.this,"Scan First!",Toast.LENGTH_LONG).show();
                }
                else
                {
                    shipmentDetailforPickup();
                }
            }
        });
        if(uid!=null)
        {
            System.out.println("uid is"+uid);
            adapter = new Scandrsadapter(Scanpickup.this,pickupmodelslist);
            scandrs1();
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {

        onBackPressed();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        return true;
    }

    @Override

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_CAMERA_REQUEST_CODE) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();

            } else {

                // Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();

            }

        }}//end onRequestPermi


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                Log.d("MainActivity", "Cancelled scan");
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
                uid=result.getContents();
                Log.d("MainActivity", "Scanned");
              //  Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
                adapter = new Scandrsadapter(Scanpickup.this,pickupmodelslist);
                scandrs1();

            }
        } else {
            // This is important, otherwise the result will not be passed to the fragment
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    public void scandrs1()
    {
        mProgressDialog = ProgressDialog.show(this, "Pick Up List", "Loading..");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fast-option.com/tamco/driver_new.php?method_name=barcodescanDrs&drs_unique_id="+uid+"&messanger_id=1", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mProgressDialog.dismiss();
                pickupmodelslist.clear();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String responsestatus = jsonObject.getString("status");
                    Log.d("ADebugTag", "Value: " + responsestatus);

                    if (responsestatus.equals("1")) {

                        JSONArray jsonarray =jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonarray.length(); i++) {
                            Pickupmodel ii = new Pickupmodel();
                            JSONObject jsonobject = jsonarray.getJSONObject(i);
                            String name = jsonobject.getString("slip_no");
                            slip=name;
                            ii.setName(name);
                            pickupmodelslist.add(ii);
                        }
                        recyclerView.setAdapter(adapter);
                        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                        adapter.notifyDataSetChanged();
                        System.out.println("response is : " + response);
                          slip_no.setText(slip);
                    }
                    else if(responsestatus.equals("0"))
                    {
                        Toast.makeText(Scanpickup.this,"AWB Not Found!",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(Scanpickup.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", ""+id);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }



    public void shipmentDetailforPickup()
    {
        mProgressDialog = ProgressDialog.show(this, "Pick Up List", "Loading..");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fast-option.com/tamco/driver_new.php?method_name=shipmentDetailforPickup&slip_no="+slip+"&messanger_id=1", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                System.out.println("response is : " + response);
                mProgressDialog.dismiss();
                pickupmodelslist.clear();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String responsestatus = jsonObject.getString("status");
                    Log.d("ADebugTag", "Value: " + responsestatus);

                    if (responsestatus.equals("1")) {

                        JSONArray jsonarray =jsonObject.getJSONArray("data");
                        for (int i = 0; i < jsonarray.length(); i++) {
                            Pickupmodel ii = new Pickupmodel();
                            JSONObject jsonobject = jsonarray.getJSONObject(i);
                            String name = jsonobject.getString("slip_no");
                         ii.setName("SHIPMENT No.:"+name+"<br> Sender Phone:"+jsonobject.getString("sender_name")+"<br> Sender Address:"+jsonobject.getString("sender_address")+"<br> Reciever Phone:"+jsonobject.getString("reciever_phone"));
                            pickupmodelslist.add(ii);
                        }
                        recyclerView.setAdapter(adapter);
                        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                        adapter.notifyDataSetChanged();
                        System.out.println("response is : " + response);

                    }
                    else if(responsestatus.equals("0"))
                    {
                        Toast.makeText(Scanpickup.this,"AWB Not Found!",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(Scanpickup.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", ""+id);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }

}
