package com.tamco.driver;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.vision.barcode.Barcode;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Mapss extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    ArrayList<LatLng> points = new ArrayList<>();
    PolylineOptions lineOptions ;
    private static final LatLng LOWER_MANHATTAN = new LatLng(40.722543,
            -73.998585);
    private static final LatLng BROOKLYN_BRIDGE = new LatLng(40.7057, -73.9964);
    private static final LatLng WALL_STREET = new LatLng(40.7064, -74.0094);
    private static final LatLng ORIGIN = new LatLng(26.8473285, -80.8784857);
    private static final LatLng DESCT = new LatLng(66.04961062044963, -172.83840849265653);
    ArrayList<HashMap<String, String>> location,location1,location2,location3;
    HashMap<String, String> map,map1,map2,map3;
    GoogleMap googleMap;
    private Double Latitude = 0.00;
    private Double Longitude = 0.00;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

       login();
        location= new ArrayList<HashMap<String, String>>();;
        map = new HashMap<String, String>();
        map.put("LocationID", "1");
        map.put("Latitude", "-31.952854");
        map.put("Longitude", "115.857342");
        map.put("LocationName", "Naveen");
        location.add(map);
        location1= new ArrayList<HashMap<String, String>>();;
        map1 = new HashMap<String, String>();
        map1.put("LocationID","2");
        map1.put("Latitude", "-33.87365");
        map1.put("Longitude", "151.20689");
        map1.put("LocationName", "Amendra");
        location1.add(map1);
        location2= new ArrayList<HashMap<String, String>>();;
        map2 = new HashMap<String, String>();
        map2.put("LocationID","3");
        map2.put("Latitude", "40.7064");
        map2.put("Longitude", "-74.0094");
        map2.put("LocationName", "Anurag");
        location2.add(map2);


        location3= new ArrayList<HashMap<String, String>>();;
        map3 = new HashMap<String, String>();
        map3.put("LocationID","3");
        map3.put("Latitude", "66.04961062044963");
        map3.put("Longitude", "-172.83840849265653");
        map3.put("LocationName", "Farhat");
        location3.add(map3);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {

        onBackPressed();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions

            return;
        }
//        lineOptions = new PolylineOptions();
//
//        RequestQueue requestQueue = Volley.newRequestQueue(this);
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://www.fast-option.com/tamco/driver_new.php?method_name=locationdeliveryMap&user_id=3&date=2019-05-17&timeslote=10:00%20AM%20-%204:00%20PM", new Response.Listener<String>() {
//
//            @Override
//            public void onResponse(String response) {
//                System.out.println(response);
//                //  mProgressDialog.dismiss();
//                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
//                try {
//
//                    JSONObject jj=new JSONObject(response);
//                    JSONArray jj1=jj.getJSONArray("path");
//                    for (int i=0;i<jj1.length();i++)
//                    {
//                        JSONObject kk=jj1.getJSONObject(i);
//                        Double lat= Double.parseDouble(kk.getString("lat"));
//                        Double lng= Double.parseDouble(kk.getString("longtitude"));
//                      //  mMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(kk.getString("lat")), Double.parseDouble(kk.getString("longtitude")));
//                       // mMap.addMarker(new MarkerOptions().position(new LatLng(""+kk.getString("lat"),kk.getString("longtitude")));
//                     //   mMap.addMarker(new MarkerOptions().position(new LatLng(""+Double.parseDouble(kk.getString("lat")),Double.parseDouble(kk.getString("longtitude")))));
//                        System.out.println(kk.getString("lat")+""+kk.getString("longtitude"));
//                     //   mMap.addMarker(new MarkerOptions().position(new LatLng(long1, lat1)).title(kk.getString("slipno")));
//                        createMarker(lat,lng, kk.getString("slipno"),"1213");
//                      //  LatLng position = new LatLng(lat, lng);
//
//                      //  points.add(position);
//                    }
//
////                    lineOptions.addAll(points);
////                    lineOptions.width(12);
////                    lineOptions.color(Color.RED);
////
////                    // Drawing polyline in the Google Map for the entire route
////                    mMap.addPolyline(lineOptions);
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                //   ''   mProgressDialog.dismiss();
//                Toast.makeText(Mapss.this, error.toString(), Toast.LENGTH_LONG).show();
//
//            }
//        }
//        ) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<String, String>();
//                params.put("id", "");
//                return params;
//            }
//        };
//
//        requestQueue.add(stringRequest);

//        mMap.setMyLocationEnabled(true);
//        createMarker(LOWER_MANHATTAN.latitude,LOWER_MANHATTAN.longitude, "1234","1213");
//        createMarker(BROOKLYN_BRIDGE.latitude,BROOKLYN_BRIDGE.longitude, "12345","1213");
//        createMarker(WALL_STREET.latitude,WALL_STREET.longitude, "123456","1213");
//        createMarker(ORIGIN.latitude,ORIGIN.longitude, "1234567","1213");
//        createMarker(DESCT.latitude,DESCT.longitude, "12345678","1213");


        MarkerOptions options = new MarkerOptions();
        options.position(new LatLng(40.722543,
                -73.998585));
        options.position(new LatLng(40.7057, -73.9964));
        options.position(new LatLng(40.7064, -74.0094));
        mMap.addMarker(options);
        String url = getMapsApiDirectionsUrl();
        System.out.println(url);
        ReadTask downloadTask = new ReadTask();
        downloadTask.execute("https://maps.googleapis.com/maps/api/directions/json?origin=40.722543,-73.998585&destination=40.722543,-73.998585&waypoints=optimize:true|40.722543,-73.998585|40.7057,-73.9964|40.7064,-74.0094&sensor=false&key=AIzaSyAv2o5ear3waD88PCYsDGqWLNd8v6kzo0U");

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(BROOKLYN_BRIDGE,
                13));
       addMarkers();

        mMap.setMyLocationEnabled(true);

      //  mMap.setMyLocationEnabled(true);
      //  mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));


//
//        Latitude = Double.parseDouble(location.get(0).get("Latitude").toString());
//        Longitude = Double.parseDouble(location.get(0).get("Longitude").toString());
//        LatLng coordinate = new LatLng(Latitude, Longitude);
//        Latitude = Double.parseDouble(location.get(0).get("Latitude").toString());
//        Longitude = Double.parseDouble(location.get(0).get("Longitude").toString());
//        String name = location.get(0).get("LocationName").toString();
//        MarkerOptions marker = new MarkerOptions().position(new LatLng(Latitude, Longitude)).title(name);
//        // marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
//        googleMap.addMarker(marker);
//
//
//        Latitude = Double.parseDouble(location1.get(0).get("Latitude").toString());
//        Longitude = Double.parseDouble(location1.get(0).get("Longitude").toString());
//        String name1 = location1.get(0).get("LocationName").toString();
//        MarkerOptions marker1 = new MarkerOptions().position(new LatLng(Latitude, Longitude)).title(name1);
//        // marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
//        googleMap.addMarker(marker1);
//
//
//        Latitude = Double.parseDouble(location2.get(0).get("Latitude").toString());
//        Longitude = Double.parseDouble(location2.get(0).get("Longitude").toString());
//        String name2 = location2.get(0).get("LocationName").toString();
//        MarkerOptions marker2 = new MarkerOptions().position(new LatLng(Latitude, Longitude)).title(name2);
//        // marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
//        googleMap.addMarker(marker2);
//
//        Latitude = Double.parseDouble(location3.get(0).get("Latitude").toString());
//        Longitude = Double.parseDouble(location3.get(0).get("Longitude").toString());
//        String name3 = location3.get(0).get("LocationName").toString();
//        MarkerOptions marker3 = new MarkerOptions().position(new LatLng(Latitude, Longitude)).title(name3);
//        // marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
//        googleMap.addMarker(marker3);
//
//        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
       // googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(coordinate, 17));


//        for (int i = 0; i < location.size(); i++) {
//            Latitude = Double.parseDouble(location.get(i).get("Latitude").toString());
//            Longitude = Double.parseDouble(location.get(i).get("Longitude").toString());
//            String name = location.get(i).get("LocationName").toString();
//            MarkerOptions marker = new MarkerOptions().position(new LatLng(Latitude, Longitude)).title(name);
//           // marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker));
//            googleMap.addMarker(marker);
//        }
//



    }
    protected Marker createMarker(double latitude, double longitude, String title, String snippet) {

        return mMap.addMarker(new MarkerOptions()
                .position(new LatLng(latitude, longitude))
                .anchor(0.5f, 0.5f)
                .title(title)
                .snippet(snippet));
    }


    public void login()
    {
//        mProgressDialog = ProgressDialog.show(this, "Pick Up List", "Loading..");
//        mProgressDialog.setCancelable(false);
//        mProgressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://www.fast-option.com/tamco/driver_new.php?method_name=locationdeliveryMap&user_id=497&date=2019-05-18&timeslote=10:00%20AM%20-%204:00%20PM", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                System.out.println(response);
              //  mProgressDialog.dismiss();
                //  Toast.makeText(Login.this,response,Toast.LENGTH_LONG).show();
                try {

                    JSONObject jj=new JSONObject(response);
                    JSONArray jj1=jj.getJSONArray("path");
                    for (int i=0;i<jj1.length();i++)
                    {
                        JSONObject kk=jj1.getJSONObject(i);
                        System.out.println(kk.getString("lat")+""+kk.getString("longtitude"));
                    }



                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
          //   ''   mProgressDialog.dismiss();
                Toast.makeText(Mapss.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", "");
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }
    public String getLocationFromAddress(String strAddress) {
        System.out.println("Naveen is in function");
        Geocoder coder = new Geocoder(Mapss.this);
        List<Address> address;

        try {
            address = coder.getFromLocationName(strAddress, 1);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            double lat = location.getLatitude();
            double lng = location.getLongitude();
            System.out.println(lat + "," + lng);
            return lat + "," + lng;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }


    private String getMapsApiDirectionsUrl() {
        String waypoints = "waypoints=optimize:true|"
                + LOWER_MANHATTAN.latitude + "," + LOWER_MANHATTAN.longitude
                + "|" + "|" + BROOKLYN_BRIDGE.latitude + ","
                + BROOKLYN_BRIDGE.longitude + "|" + WALL_STREET.latitude + ","
                + WALL_STREET.longitude;
        String OriDest = "origin="+ORIGIN.latitude+","+ORIGIN.longitude+"&destination="+DESCT.latitude+","+DESCT.longitude;

        String sensor = "sensor=false";
        String params = OriDest+"&"+waypoints+"&"+sensor;
        String output = "json";
        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+params+"&key=AIzaSyAv2o5ear3waD88PCYsDGqWLNd8v6kzo0U";
        return url;
    }

    private void addMarkers() {
        if (mMap != null) {
            mMap.addMarker(new MarkerOptions().position(ORIGIN)
                    .title("First Point"));
            mMap.addMarker(new MarkerOptions().position(BROOKLYN_BRIDGE)
                    .title("First Point"));
            mMap.addMarker(new MarkerOptions().position(LOWER_MANHATTAN)
                    .title("Second Point"));
            mMap.addMarker(new MarkerOptions().position(WALL_STREET)
                    .title("Third Point"));
            mMap.addMarker(new MarkerOptions().position(DESCT)
                    .title("First Point"));
        }
    }

    private class ReadTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... url) {
            String data = "";
            try {
                HttpConnection http = new HttpConnection();
                data = http.readUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            new ParserTask().execute(result);
        }
    }

    private class ParserTask extends
            AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        @Override
        protected List<List<HashMap<String, String>>> doInBackground(
                String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                PathJSONParser parser = new PathJSONParser();
                routes = parser.parse(jObject);
               // System.out.println("routes is "+routes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> routes) {
            ArrayList<LatLng> points = null;
            PolylineOptions polyLineOptions = null;

            // traversing through routes
            for (int i = 0; i < routes.size(); i++) {
                points = new ArrayList<LatLng>();
                polyLineOptions = new PolylineOptions();
                List<HashMap<String, String>> path = routes.get(i);

                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);
                    //System.out.println(lng+"jhfcuwejhweh"+lng);
                    points.add(position);
                }

                polyLineOptions.addAll(points);
                polyLineOptions.width(2);
                polyLineOptions.color(Color.BLUE);
            }

            mMap.addPolyline(polyLineOptions);
        }
    }
}
